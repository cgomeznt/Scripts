#!/bin/sh

AGENT="DB_REPLICA"

function start {
    echo "Iniciando el agente $AGENT "
    /usr/bin/nohup /CDC/TS_Informix/bin/dmts64 -I $AGENT &
    sleep 2
    echo "Dentro del archivo nohup.out esta la salida de este comando"
    echo "Puede consultar con status"
}

function stop {
    echo "Deteniendo el agente $AGENT "
    /usr/bin/nohup /CDC/TS_Informix/bin/dmshutdown -I $AGENT &
    sleep 5
    PROC=$(ps -ef | grep -w "$AGENT" | grep -v grep | wc -l)
    if [ $PROC -gt 0 ] ; then
        /usr/bin/kill -9 `ps -ef | grep -w "$AGENT" | grep -v grep | awk '{print $2}'`
    fi
    echo "Detenido el agente $AGENT"
    echo "Puede consultar con status"
}

function restart {
    stop
    sleep 4
    start
}

function status {
    echo ""
    PROC=$(ps -ef | grep -w "$AGENT" | grep -v grep | wc -l)
    if [ $PROC -eq 1 ] ; then
       echo "Esta arriba el agente $AGENT y es este :"
       ps -ef | grep -w "$AGENT" | grep -v grep
        echo "Chequeando el puerto 11004: "
        netstat -na | grep -w 11004
    elif [ $PROC -eq 0 ] ; then
        echo "El proceso del agente $AGENT no EXISTE...!!!"
    else
        echo "Warning...!!! hay varios procesos y solo debe existir uno...!!!"
        ps -ef | grep -w "$AGENT" | grep -v grep
        echo ""
    fi
    echo ""
}
case "$1" in
    start|stop|restart)
        $1
        ;;
    status)
        status
        ;;
    *)
        echo "Debe usar: $0 {start|stop|status|restart}"
        exit 2
        ;;
esac

