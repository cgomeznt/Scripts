#!/bin/sh


function start {
    echo "Iniciando el agente $AGENT "
    /CDC/TS_AccessServer/bin/dmaccessserver &
    sleep 2
    echo "Puede consultar con status"
}

function stop {
    echo "Deteniendo el Access Server"
    /CDC/TS_AccessServer/bin/dmshutdownserver &
    sleep 5
    PROC=$(ps -ef | grep -w "dmaccessserver" | grep -v grep | wc -l)
    if [ $PROC -gt 0 ] ; then
        kill -9 `ps -ef | grep -w "dmaccessserver" | grep -v grep | awk '{print $2}'`
    fi
    echo "Detenido el Access Server"
    echo "Puede consultar con status"
}

function restart {
    stop
    sleep 4
    start
}

function status {
    echo ""
    PROC=$(ps -ef | grep -w "dmaccessserver" | grep -v grep | wc -l)
    if [ $PROC -eq 1 ] ; then
        echo "Esta arriba el proceso de Access Server y es este: "
        ps -ef | grep -w "dmaccessserver" | grep -v grep  
        echo "Chequeando el puerto 11010: "
        netstat -na | grep -w 11010
    elif [ $PROC -eq 0 ] ; then
        echo "El proceso de Access Server no EXISTE...!!!"
    else
	echo "Warning...!!! hay varios procesos y solo debe existir uno...!!!"
        ps -ef | grep -w "dmaccessserver" | grep -v grep
        echo ""
    fi
}
case "$1" in
    start|stop|restart)
        $1
        ;;
    status)
        status
        ;;
    *)
        echo "Debe usar: $0 {start|stop|status|restart}"
        exit 2
        ;;
esac

